package fatec.sp.gov.br.firstspring.dto;

public class GetTssAvgDataDTO {
    private Double tssAvgMin;

    private Double tssExpPlat;

    private Double tssExpContent;

    public Double getTssAvgMin() {
        return tssAvgMin;
    }

    public void setTssAvgMin(Double tssAvgMin) {
        this.tssAvgMin = tssAvgMin;
    }

    public Double getTssExpPlat() {
        return tssExpPlat;
    }

    public void setTssExpPlat(Double tssExpPlat) {
        this.tssExpPlat = tssExpPlat;
    }

    public Double getTssExpContent() {
        return tssExpContent;
    }

    public void setTssExpContent(Double tssExpContent) {
        this.tssExpContent = tssExpContent;
    }

    
}
