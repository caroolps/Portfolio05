package fatec.sp.gov.br.firstspring.view;

public class View {
    
    public static class Login{};

    public static class LoginAll extends Login{};

    public static class Category{};

    public static class Auth{};

    public static class Profile extends Login{};
    
    public static class UserProfile extends Login{};

    public static class Task extends UserProfile{}; 

}
